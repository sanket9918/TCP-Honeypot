Sanpot QuickStart
=================

Simple and smart TCP Honeypot

Installation
---------------

    python3 -m pip install sanpot

Source Code
---------------
https://github.com/sanket9918/TCP-Honeypot

Installation as Debian package
----------------
Get the debian package from github release and run:

    sudo dpkg -i sanpot-1.0.0.deb

Enable service with 
    
    sudo systemctl enable sanpot
